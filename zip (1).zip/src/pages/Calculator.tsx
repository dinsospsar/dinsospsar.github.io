import { useState, FormEvent } from "react";
import { Calculator as CalcIcon, Activity, Droplets, Heart, Info } from "lucide-react";

export function Calculator() {
  const [isCalculated, setIsCalculated] = useState(false);

  const handleCalculate = (e: FormEvent) => {
    e.preventDefault();
    setIsCalculated(true);
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <div className="relative h-[40vh] min-h-[300px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAlvQZ5rLxSxJTawi6KBQrqithyDmy8vA1M8pXly7XRegjulR4lRdBN6y6nYfjomFH3GpHdCqYslWFuPJChu2f0zNCdmBEUZAmq-XkwfCMa5AWZEjPeWybCzzScanG8AD9v7pOwdy8YpqUCq6yxIR4uB8YOlyN7tYPwHCegJNRigkp26H-xpsP8k1SZD3XYmFwSXEptJS7JSE-TNtfERvI2OAqB8hN5PKq0tSaxR5KqV5vIE4E7Wz0Pd1p2eG8i7CS7-FmpsCPnFTo"
            alt="Calculator background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-primary/80 mix-blend-multiply"></div>
        </div>
        <div className="relative z-10 text-center px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-surface-container-lowest mb-4">
            Kalkulator Gizi Personal
          </h1>
          <p className="text-lg md:text-xl text-surface-container-lowest/90 max-w-2xl mx-auto">
            Ketahui kebutuhan kalori harian dan status gizi Anda untuk merencanakan pola makan yang lebih sehat.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 -mt-20 relative z-20">
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* Form Section */}
          <div className="lg:col-span-5">
            <div className="bg-surface-container-lowest rounded-[2rem] p-8 shadow-lg border border-surface-variant/20">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                  <CalcIcon size={24} />
                </div>
                <h2 className="text-2xl font-bold text-on-surface">Data Metrik Anda</h2>
              </div>

              <form onSubmit={handleCalculate} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-on-surface-variant mb-2">Jenis Kelamin</label>
                    <select className="w-full bg-surface-container-low border-none rounded-xl px-4 py-3 text-on-surface focus:ring-2 focus:ring-primary outline-none">
                      <option>Laki-laki</option>
                      <option>Perempuan</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-on-surface-variant mb-2">Usia (Tahun)</label>
                    <input type="number" defaultValue={25} className="w-full bg-surface-container-low border-none rounded-xl px-4 py-3 text-on-surface focus:ring-2 focus:ring-primary outline-none" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-on-surface-variant mb-2">Tujuan</label>
                  <select className="w-full bg-surface-container-low border-none rounded-xl px-4 py-3 text-on-surface focus:ring-2 focus:ring-primary outline-none">
                    <option>Menjaga Berat Badan</option>
                    <option>Menurunkan Berat Badan</option>
                    <option>Menaikkan Berat Badan</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-on-surface-variant mb-2">Tinggi (cm)</label>
                    <input type="number" defaultValue={170} className="w-full bg-surface-container-low border-none rounded-xl px-4 py-3 text-on-surface focus:ring-2 focus:ring-primary outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-on-surface-variant mb-2">Berat (kg)</label>
                    <input type="number" defaultValue={65} className="w-full bg-surface-container-low border-none rounded-xl px-4 py-3 text-on-surface focus:ring-2 focus:ring-primary outline-none" />
                  </div>
                </div>

                <button type="submit" className="w-full bg-primary text-surface-container-lowest py-4 rounded-xl font-bold text-lg hover:bg-primary/90 transition-colors mt-4">
                  Hitung Kebutuhan
                </button>
              </form>
            </div>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-7">
            {isCalculated ? (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="bg-primary text-on-primary p-8 rounded-[2rem] shadow-lg">
                  <h2 className="text-3xl font-bold text-surface-container-lowest mb-2">Keseimbangan Sehat</h2>
                  <p className="text-on-primary/90 mb-8">Berdasarkan data Anda, berikut adalah estimasi kebutuhan harian.</p>
                  
                  <div className="grid sm:grid-cols-3 gap-6">
                    <div className="bg-surface-container-lowest/10 rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity size={20} className="text-surface-container-lowest" />
                        <span className="font-medium text-surface-container-lowest">Skor BMI</span>
                      </div>
                      <div className="text-3xl font-bold text-surface-container-lowest">22.5</div>
                      <div className="text-sm text-on-primary/80 mt-1">Normal</div>
                    </div>
                    <div className="bg-surface-container-lowest/10 rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Heart size={20} className="text-surface-container-lowest" />
                        <span className="font-medium text-surface-container-lowest">Kalori Harian</span>
                      </div>
                      <div className="text-3xl font-bold text-surface-container-lowest">2,150</div>
                      <div className="text-sm text-on-primary/80 mt-1">kkal/hari</div>
                    </div>
                    <div className="bg-surface-container-lowest/10 rounded-2xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Droplets size={20} className="text-surface-container-lowest" />
                        <span className="font-medium text-surface-container-lowest">Hidrasi</span>
                      </div>
                      <div className="text-3xl font-bold text-surface-container-lowest">2.5</div>
                      <div className="text-sm text-on-primary/80 mt-1">Liter/hari</div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-on-surface mb-6">Rekomendasi Pangan Lokal</h3>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="bg-surface-container-lowest rounded-2xl overflow-hidden shadow-sm border border-surface-variant/20 flex">
                      <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuBhPHbG48yUYylsOx0ONn2byvs7nTbeAlUE-o1sXyifB3EfFA--3kYVU_rUQTggF1PjNjDq8LFENj1f3BgEaaT799FnrIsB_Dv8RCEk5Gw-cktlBkv_6nl4MXMVBWz3LQVkLgINCUER74C6etsrUDedt_TQOAsNy8fpAH2zBHsZ3Oq7y1F81nhjRposn2DvtSckFeS3sH3sQD981RWKsMXADdhTmD58SxfXuuRSRyZZ3sAca4Bk1cKakT166fqYqhWI7U9LXwjxTmU" alt="Sayur Daun Singkong" className="w-1/3 object-cover" referrerPolicy="no-referrer" />
                      <div className="p-4 w-2/3">
                        <h4 className="font-bold text-on-surface mb-1">Sayur Daun Singkong</h4>
                        <p className="text-sm text-on-surface-variant">Kaya zat besi dan serat, baik untuk pencernaan.</p>
                      </div>
                    </div>
                    <div className="bg-surface-container-lowest rounded-2xl overflow-hidden shadow-sm border border-surface-variant/20 flex">
                      <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAQPCFlbwML4NvLaixlL3SiiqLOHob5XpxsSW0ur0Tg-gtIZ82zQ8gt9LLj_PBYcS0wmmCSRk2lnAG20p3q3XefRdadZmtpVWUN_3GK__bEf7VUCCmYnfOKsDWXyS1aB9agG-2iFGqtZfErYU8D1FKheNiMVHNkNUuScYX1H2xG68DydmfHMdiEML3b-l1zhRmmw4NfmweAaHT34BV1Tb8N2rZr_7Cfr28EWJtuTVap0hEmqV8Mw2Hp_OQM96puWKxcy1_LjWTjG_o" alt="Ikan Arsik" className="w-1/3 object-cover" referrerPolicy="no-referrer" />
                      <div className="p-4 w-2/3">
                        <h4 className="font-bold text-on-surface mb-1">Ikan Mas Arsik</h4>
                        <p className="text-sm text-on-surface-variant">Sumber protein tinggi dengan rempah antioksidan.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-12 bg-surface-container-low rounded-[2rem] border border-surface-variant/30 border-dashed">
                <div className="w-20 h-20 bg-surface-container-lowest rounded-full flex items-center justify-center text-primary/40 mb-6 shadow-sm">
                  <CalcIcon size={40} />
                </div>
                <h3 className="text-2xl font-bold text-on-surface mb-2">Belum Ada Data</h3>
                <p className="text-on-surface-variant max-w-md">
                  Silakan isi formulir di samping dan klik "Hitung Kebutuhan" untuk melihat hasil analisis gizi personal Anda.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Info Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-16">
          <div className="bg-secondary-container/50 p-6 rounded-3xl">
            <div className="w-10 h-10 bg-secondary-container rounded-xl flex items-center justify-center text-on-secondary-container mb-4">
              <Info size={20} />
            </div>
            <h4 className="font-bold text-on-surface mb-2">Konsumsi Berkesadaran</h4>
            <p className="text-sm text-on-surface-variant">Perhatikan porsi makan dan nikmati setiap gigitan untuk pencernaan yang lebih baik.</p>
          </div>
          <div className="bg-tertiary-container/50 p-6 rounded-3xl">
            <div className="w-10 h-10 bg-tertiary-container rounded-xl flex items-center justify-center text-on-tertiary-container mb-4">
              <Activity size={20} />
            </div>
            <h4 className="font-bold text-on-surface mb-2">Aktif Bergerak</h4>
            <p className="text-sm text-on-surface-variant">Kombinasikan pola makan sehat dengan aktivitas fisik minimal 30 menit sehari.</p>
          </div>
          <div className="bg-surface-container-low p-6 rounded-3xl">
            <div className="w-10 h-10 bg-surface-container-high rounded-xl flex items-center justify-center text-on-surface mb-4">
              <Heart size={20} />
            </div>
            <h4 className="font-bold text-on-surface mb-2">Dukungan Ahli</h4>
            <p className="text-sm text-on-surface-variant">Hasil kalkulator ini adalah estimasi. Konsultasikan dengan ahli gizi untuk program spesifik.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
