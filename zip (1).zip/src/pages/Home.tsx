import { ArrowRight, Calendar, FileText, MessageCircle } from "lucide-react";

export function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCE4hQ7ywNfLVX93A7gM2awbVHRnCiJJyqiUwY6bXa8Au1HAD6Ktw3LMhbuMSIREOxayR1qyKppNONAlvbfjbXV3S94MXyT9gPRxtw89NukvO1CjZ6YA2iWvYDw5wf3ZPQXEOb8X7K2yUQ8AtMngV1eJsLOG771NNiqzvsemLxBc94MgVobZ24toy3vwowBhv4Ogxw6v_B9ayIrQHVcZZj2WWjcRGMYQKV59anbQpjGerEkPK7jlw42OwEGkzu-caIohB9sgMf9StM"
            alt="Healthy food background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-surface/90 via-surface/70 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold text-primary leading-tight mb-6">
              Nutrisi Tepat,<br />Generasi Kuat
            </h1>
            <p className="text-lg md:text-xl text-on-surface-variant mb-8 leading-relaxed">
              Membangun masa depan Sumatera Utara melalui pelayanan gizi yang komprehensif, edukasi berkelanjutan, dan pendampingan masyarakat.
            </p>
            <button className="bg-primary text-surface-container-lowest px-8 py-4 rounded-full text-lg font-medium hover:bg-primary/90 transition-all flex items-center gap-2 group">
              Mulai Konsultasi
              <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Sambutan Section */}
      <section className="py-24 bg-surface-container-low">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-secondary-container rounded-[3rem] transform translate-x-4 translate-y-4"></div>
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuC2mUrCWHFvbIe0p_ZBV0paYBZz1hdhUA-tzvC-lUA-9GKZOZTy6Gk45vf3azYd7Xqdzo8LNihNuHBUdwDB02QLf0uVpX0Ognbn7UYOsFnsnyAb2G5oZkd4iWGFi8GdmwfW0PNVWmHsxXvox6sCWIKRY0YrLCgEMGU2Y2mrUXhmzDcAvDxdV5SLmjZcezPrhyjqdoDxaR2vC9gQncPlejX7o1fx6nB6vxug5m2i6XxQS08F6GjWZrwdGsD5xfk43TXK8kC0yxSZ84I"
                alt="Kepala Dinas Sosial"
                className="relative z-10 w-full h-[600px] object-cover rounded-[3rem] shadow-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">Sambutan Kepala Dinas</h2>
              <h3 className="text-4xl font-bold text-on-surface mb-6 leading-tight">
                Bersama Mewujudkan Keluarga Sehat dan Sejahtera
              </h3>
              <div className="space-y-4 text-on-surface-variant text-lg leading-relaxed">
                <p>
                  Melalui UPTD PSAR Gizi, kami berkomitmen untuk memberikan pelayanan terbaik bagi masyarakat Sumatera Utara. Gizi yang baik adalah fondasi utama bagi pertumbuhan dan perkembangan generasi penerus bangsa.
                </p>
                <p>
                  Kami mengajak seluruh lapisan masyarakat untuk aktif berpartisipasi dalam program-program kesehatan dan gizi yang kami selenggarakan. Mari bersama-sama kita ciptakan lingkungan yang mendukung pola hidup sehat.
                </p>
              </div>
              <div className="mt-8 pt-8 border-t border-surface-variant/30">
                <p className="font-headline font-bold text-xl text-on-surface">Dr. Illyan Chandra Simbolon, S.STP., M.SP</p>
                <p className="text-primary">Kepala Dinas Sosial Provinsi Sumatera Utara</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Akses Cepat Layanan (Bento Grid) */}
      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-on-surface mb-4">Akses Cepat Layanan</h2>
            <p className="text-on-surface-variant text-lg">
              Pilih layanan yang Anda butuhkan untuk mendapatkan informasi dan bantuan seputar gizi dan kesehatan.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <div className="bg-primary text-on-primary p-10 rounded-[2rem] flex flex-col md:flex-row items-center justify-between group cursor-pointer hover:shadow-lg transition-all">
              <div className="flex items-center gap-8 mb-6 md:mb-0">
                <div className="w-16 h-16 bg-surface-container-lowest/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <MessageCircle size={32} className="text-surface-container-lowest" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-surface-container-lowest mb-2">Konsultasi Gizi Online</h3>
                  <p className="text-on-primary/90 text-lg max-w-2xl">
                    Dapatkan saran langsung dari ahli gizi kami secara gratis melalui platform konsultasi online.
                  </p>
                </div>
              </div>
              <div className="flex items-center font-medium whitespace-nowrap bg-surface-container-lowest/20 px-6 py-3 rounded-full text-surface-container-lowest">
                Mulai Chat <ArrowRight className="ml-2 group-hover:translate-x-2 transition-transform" size={20} />
              </div>
            </div>

            <div className="bg-tertiary-container text-on-tertiary-container p-10 rounded-[2rem] flex flex-col md:flex-row items-center justify-between group cursor-pointer hover:shadow-lg transition-all">
              <div className="flex items-center gap-8 mb-6 md:mb-0">
                <div className="w-16 h-16 bg-surface-container-lowest/50 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <FileText size={32} className="text-on-tertiary-container" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">Artikel Kesehatan & Resep Bergizi</h3>
                  <p className="text-on-tertiary-container/80 text-lg max-w-2xl">
                    Pelajari lebih lanjut tentang pola makan sehat dan temukan resep masakan bergizi untuk keluarga.
                  </p>
                </div>
              </div>
              <div className="flex items-center font-medium whitespace-nowrap bg-surface-container-lowest/30 px-6 py-3 rounded-full">
                Baca Artikel <ArrowRight className="ml-2 group-hover:translate-x-2 transition-transform" size={20} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-24 bg-primary text-surface-container-lowest">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Dapatkan Info Gizi Terbaru</h2>
          <p className="text-on-primary text-lg mb-10 max-w-2xl mx-auto">
            Berlangganan newsletter kami untuk menerima tips kesehatan, resep bergizi, dan informasi layanan terbaru langsung di kotak masuk Anda.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
            <input
              type="email"
              placeholder="Alamat Email Anda"
              className="flex-grow px-6 py-4 rounded-full bg-surface-container-lowest/10 border border-surface-container-lowest/20 text-surface-container-lowest placeholder:text-surface-container-lowest/50 focus:outline-none focus:ring-2 focus:ring-surface-container-lowest/50"
            />
            <button
              type="button"
              className="px-8 py-4 rounded-full bg-surface-container-lowest text-primary font-bold hover:bg-surface transition-colors whitespace-nowrap"
            >
              Berlangganan
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
