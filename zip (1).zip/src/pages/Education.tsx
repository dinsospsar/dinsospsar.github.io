import { BookOpen, Clock, Star, ArrowRight } from "lucide-react";

export function Education() {
  const modules = [
    {
      id: 1,
      title: "Dasar Gizi Seimbang",
      category: "Diet",
      image: "https://picsum.photos/seed/nutrition1/600/400",
      duration: "15 min",
      rating: "4.8",
      description: "Pahami konsep piring makanku dan proporsi ideal karbohidrat, protein, dan sayuran."
    },
    {
      id: 2,
      title: "Nutrisi Remaja: Bekal Masa Depan",
      category: "Growth",
      image: "https://picsum.photos/seed/nutrition2/600/400",
      duration: "20 min",
      rating: "4.9",
      description: "Kebutuhan gizi spesifik untuk mendukung pertumbuhan optimal di masa pubertas."
    },
    {
      id: 3,
      title: "Pentingnya Zat Besi",
      category: "Diet",
      image: "https://picsum.photos/seed/nutrition3/600/400",
      duration: "10 min",
      rating: "4.7",
      description: "Mencegah anemia dengan konsumsi makanan kaya zat besi dan vitamin C."
    },
    {
      id: 4,
      title: "Aktivitas Fisik Harian",
      category: "Exercise",
      image: "https://picsum.photos/seed/nutrition4/600/400",
      duration: "25 min",
      rating: "4.9",
      description: "Panduan olahraga ringan yang bisa dilakukan di rumah untuk menjaga kebugaran."
    },
    {
      id: 5,
      title: "Membaca Label Makanan",
      category: "Diet",
      image: "https://picsum.photos/seed/nutrition5/600/400",
      duration: "15 min",
      rating: "4.6",
      description: "Cara cerdas memilih produk kemasan dengan memperhatikan informasi nilai gizi."
    },
    {
      id: 6,
      title: "Gizi untuk Kecerdasan",
      category: "Growth",
      image: "https://picsum.photos/seed/nutrition6/600/400",
      duration: "20 min",
      rating: "4.8",
      description: "Makanan sumber omega-3 dan nutrisi penting lainnya untuk perkembangan otak."
    }
  ];

  return (
    <div className="min-h-screen bg-surface pt-10 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-on-surface mb-4">Modul Edukasi</h1>
          <p className="text-lg text-on-surface-variant max-w-2xl">
            Tingkatkan pengetahuan Anda tentang gizi dan kesehatan melalui modul pembelajaran interaktif yang disusun oleh para ahli.
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-12">
          <button className="px-6 py-2 rounded-full bg-primary text-surface-container-lowest font-medium text-sm">
            Semua Modul
          </button>
          <button className="px-6 py-2 rounded-full bg-surface-container-lowest border border-surface-variant text-on-surface-variant hover:border-primary hover:text-primary transition-colors font-medium text-sm">
            Diet & Pola Makan
          </button>
          <button className="px-6 py-2 rounded-full bg-surface-container-lowest border border-surface-variant text-on-surface-variant hover:border-primary hover:text-primary transition-colors font-medium text-sm">
            Pertumbuhan
          </button>
          <button className="px-6 py-2 rounded-full bg-surface-container-lowest border border-surface-variant text-on-surface-variant hover:border-primary hover:text-primary transition-colors font-medium text-sm">
            Aktivitas Fisik
          </button>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {modules.map((module) => (
            <div key={module.id} className="bg-surface-container-lowest rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-shadow group">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={module.image} 
                  alt={module.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 bg-surface-container-lowest/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-primary uppercase tracking-wider">
                  {module.category}
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-4 text-sm text-on-surface-variant mb-3">
                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>{module.duration}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-500">
                    <Star size={16} className="fill-current" />
                    <span className="text-on-surface-variant">{module.rating}</span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-on-surface mb-2 line-clamp-2">
                  {module.title}
                </h3>
                <p className="text-on-surface-variant text-sm mb-6 line-clamp-2">
                  {module.description}
                </p>
                <button className="flex items-center text-primary font-semibold hover:text-primary/80 transition-colors">
                  Pelajari Selengkapnya <ArrowRight size={18} className="ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Coming Soon Banner */}
        <div className="bg-secondary-container rounded-[2rem] p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 bg-surface-container-lowest/50 px-4 py-2 rounded-full text-sm font-bold text-on-secondary-container mb-4">
              <BookOpen size={18} /> Segera Hadir
            </div>
            <h2 className="text-3xl font-bold text-on-secondary-container mb-4">
              Interactive Meal Planner
            </h2>
            <p className="text-on-secondary-container/80 text-lg">
              Rencanakan menu makan mingguan Anda dengan mudah. Dapatkan rekomendasi resep yang disesuaikan dengan kebutuhan kalori dan preferensi diet Anda.
            </p>
          </div>
          <div className="flex-shrink-0">
            <button className="bg-surface-container-lowest text-on-secondary-container px-8 py-4 rounded-full font-bold hover:bg-surface transition-colors shadow-sm">
              Beritahu Saya
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
