import { Leaf } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-surface-container-low py-12 mt-auto border-t border-surface-variant/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary">
              <Leaf size={16} />
            </div>
            <span className="font-headline font-semibold text-on-surface">
              UPTD PSAR Gizi Sumatera Utara
            </span>
          </div>
          <div className="flex gap-6 text-sm text-on-surface-variant">
            <a href="#" className="hover:text-primary transition-colors">Tentang Kami</a>
            <a href="#" className="hover:text-primary transition-colors">Kontak</a>
            <a href="#" className="hover:text-primary transition-colors">Kebijakan Privasi</a>
          </div>
          <p className="text-sm text-on-surface-variant">
            © {new Date().getFullYear()} UPTD PSAR Gizi. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
