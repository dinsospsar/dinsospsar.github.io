import { Link, useLocation } from "react-router-dom";
import { Menu, X, Leaf } from "lucide-react";
import { useState } from "react";
import { cn } from "../lib/utils";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    { name: "Beranda", path: "/" },
    { name: "Edukasi", path: "/education" },
    { name: "Kalkulator", path: "/calculator" },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass border-b border-surface-variant/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex-shrink-0 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-on-primary">
              <Leaf size={20} />
            </div>
            <Link to="/" className="font-headline font-bold text-xl text-primary">
              UPTD PSAR Gizi
            </Link>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location.pathname === link.path
                    ? "text-primary border-b-2 border-primary py-1"
                    : "text-on-surface-variant"
                )}
              >
                {link.name}
              </Link>
            ))}
            <button className="bg-primary text-surface-container-lowest px-6 py-2.5 rounded-full text-sm font-medium hover:bg-primary/90 transition-colors">
              Masuk
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-on-surface-variant hover:text-primary p-2"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-surface-container-lowest border-b border-surface-variant/50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setIsOpen(false)}
                className={cn(
                  "block px-3 py-2 rounded-md text-base font-medium",
                  location.pathname === link.path
                    ? "bg-primary/10 text-primary"
                    : "text-on-surface-variant hover:bg-surface-container-low hover:text-primary"
                )}
              >
                {link.name}
              </Link>
            ))}
            <button className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-primary hover:bg-primary/10">
              Masuk
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
